'use strict'

import jwt from 'jsonwebtoken'
import Admin from '../admin/admin.model.js'

//FUNCIÓN MIDDLEWARE PARA VALIDAR TOKENS JWT EN LAS SOLICITUDES. 
export const validateJwt = async (req, res, next) => {
    try {
        //OBTIENE LA CLAVE SECRETA DESDE LAS VARIABLES DE ENTORNO. 
        let secretKey = process.env.SECRET_KEY;

        //OBTIENE EL HEADER DE AUTORIZACIÓN DE LA SOLICITUD.
        const authHeader = req.headers['authorization'];

        //SI EL HEADER DE AUTORIZACIÓN ESTÁ PRESENTE, OBTIENE EL TOKEN.
        const token = authHeader && authHeader.split(' ')[1];

        //SI NO SER PROPORCIONA EL TOKEN, RESPONDE CON UN CÓDIGO DE ESTADO 401 NO AUTORIZADO.
        if (!token) return res.status(401).send({ message: 'Unauthorized' });

        //VERIFICA EL TOKEN UTILIZANDO LA CLAVE SECRETA.
        //EXTRAE EL "UID" ID DE USUARIO DEL PAYLOAD DEL TOKEN SI LA VERIFICACIPON ES EXITOSA.
        let { uid } = jwt.verify(token, secretKey);

        //BUSCA EN LA BASE DE DATOS UN ADMINISTRADOR CON EL UID EXTRAÍDO DEL TOKEN.
        let admin = await Admin.findOne({ _id: uid });

        //SI NO SE ENCUENTRA UN ADMINISTRADOR CON ESE UID, RESPONDE CON UN CÓDIGO DE ESTADO 404 NO ENCONTRADO.
        if (!admin) return res.status(404).send({ message: 'User not found - Unauthorized' });

        //SI ENCUENTRA UN ADMINISTRADOR, SE ASIGNA AL OBJETO DE SOLICITUD PARA QUE ESTE DISPONIBLE EN LOS SIGUIENTES MIDDLEWARES.
        req.admin = admin;

        //LLAMA A LA SIGUIENTE FUNCIÓN MIDDLEWARE O CONTROLADOR EN LA CADENA DE EJECUCIÓN.
        next();
    } catch (error) {
        console.error(error);
        return res.status(401).send({ message: 'Invalid token' }); //EN CASO DE ERROR, SE RESPONDE CON UN MENSAJE DE ERROR.
    }
}
