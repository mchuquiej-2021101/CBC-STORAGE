/*
    MIDDLEWARE CREADO: Lunes 26/08/2024
    ÚLTIMA ACTUALIZACIÓN: Martes 03/09/2024 11:21AM
*/

import jwt from 'jsonwebtoken';

//DEFINE UNA CLAVE SECRETA PARA VERIFICAR LOS TOKENS.
//SI NO SE PROPORCIONA UNA CLAVE EN LAS VARIABALES DE ENTORNO, SE UTILIZA UNA CLAVE POR DEFECTO.
const secretKey = process.env.JWT_SECRET || '@CBC8d42e9d4f3a29b1e7cbd34f1d937fc8e3f6f86a@'; 

//FUNCION PARA AUTENTICAR TOKENS EN LAS SOLICITUDES. 
export const authenticateToken = (req, res, next) => {
    //OBTIENE EL HEADER DE AUTORIZACIPON DE LA SOLICITUD.
    const authHeader = req.headers['authorization'];

    //SI EL HEADER DE LA AUTORIZACIÓN ESTÁ PRESENTE, SE OBTIENE EL TOKEN. 
    const token = authHeader && authHeader.split(' ')[1];

    //SI NO SE PROPORCIONA UN TOKEN, SE RESPONDE CON UN CÓDIGO DE ESTADO 401 NO AUTORIZADO.
    if (!token) {
        return res.status(401).send({ message: 'Token no proporcionado.' });
    }

    //VERIFICA EL TOKEN JWET UTILIZANDO LA CLAVE SECRETA. 
    jwt.verify(token, secretKey, (err, user) => {
        //SI LA VERIFICACIÓN FALLA, SI EL TOKEN ES INVALIDO, RESPONDE CON UN MENSAJE 403. 
        if (err) {
            return res.status(403).send({ message: 'El token es inválido.' });
        }

        //SI EL TOKEN ES VÁLIDO, ASIGNA LA INFORMACIÓN DEL USUARIO DECODIFICANCO AL OBJETO DE SOLICITUD                
        req.user = user; 
        
        //LLAMA A LA SIGUIENTE FUNCIÓN MIDDLEWARE O CONTROLADOR A LA CADENA DE EJECUCIÓN.
        next();
    });
};