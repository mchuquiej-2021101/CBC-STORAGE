'use strict'

import Ubicacion from './ubicacion.model.js'; // Importa el modelo de Ubicación
import Herramienta from '../herramienta/herramienta.model.js'; // Importa el modelo de Herramienta

//CREAR Y GUARDAR UBICACIONES. 
export const save = async (req, res) => {
    try {
        let data = req.body; // Captura los datos del cuerpo de la solicitud
        let ubicacion = new Ubicacion(data); // Crea una nueva instancia del modelo Ubicación con los datos recibidos

        // Verifica si la ubicación ya existe
        let ubicacionEncontrada = await Ubicacion.find({
            ubicacion: data.ubicacion
        });

        if (ubicacionEncontrada.length > 0) {
            return res.status(400).send({ message: 'La ubicación ya existe' }); // Responde si la ubicación ya está registrada
        }

        // Campos requeridos para crear una ubicación
        const requiredFields = ['ubicacion', 'capacidad']; 
                
        // Verifica que todos los campos requeridos estén presentes en los datos
        for (let field of requiredFields) {
            if (!data[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` }); // Responde si falta algún campo requerido
            }
        }

        await ubicacion.save(); // Guarda la nueva ubicación en la base de datos
        return res.send({ message: 'Ubicación guardada exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al agregar ubicación' }); // Responde en caso de error
    }
};

//OBTENER UBICACIONES. 
export const get = async (req, res) => {
    try {
        let ubicaciones = await Ubicacion.find(); // Busca todas las ubicaciones en la base de datos
        if (ubicaciones.length == 0) return res.status(404).send({ message: 'No hay ubicaciones que mostrar' }); // Responde si no hay ubicaciones registradas
        return res.send({ ubicaciones }); // Responde con la lista de ubicaciones
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al mostrar ubicaciones' }); // Responde en caso de error
    }
};

//ACTUALIZAR UBICACIONES. 
export const update = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID de la ubicación desde los parámetros de la URL
        let data = req.body; // Captura los datos del cuerpo de la solicitud

        // Verifica si la nueva ubicación ya existe
        let ubicacionEncontrada = await Ubicacion.find({
            ubicacion: data.ubicacion
        });

        if (ubicacionEncontrada.length > 0) {
            return res.status(400).send({ message: 'La ubicación ya existe' }); // Responde si la ubicación ya está registrada
        }

        // Actualiza la ubicación en la base de datos con los nuevos datos
        let updatedUbicacion = await Ubicacion.findOneAndUpdate(
            { _id: id },
            data,
            { new: true } // Retorna la ubicación actualizada
        );

        if (!updatedUbicacion) return res.status(404).send({ message: 'Ubicación no encontrada y no actualizada' }); // Responde si la ubicación no fue encontrada o actualizada
        return res.send({ message: 'Ubicación actualizada exitosamente', updatedUbicacion }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al actualizar ubicación' }); // Responde en caso de error
    }
};

//ELIMINAR UBICACIONES. 
export const deleteUbicacion = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID de la ubicación desde los parámetros de la URL

        // Verifica si existe una ubicación "Default Location", y si no, la crea
        let defaultLocation = await Ubicacion.findOne({ ubicacion: 'Default Location' });
        if (!defaultLocation) {
            defaultLocation = await Ubicacion.create({ ubicacion: 'Default Location', capacidad: 0 });
        }

        // Asigna todas las herramientas que estaban en la ubicación eliminada a la "Default Location"
        await Herramienta.updateMany({ ubicacion: id }, { $set: { ubicacion: defaultLocation._id } });

        // Elimina la ubicación de la base de datos
        let deletedUbicacion = await Ubicacion.deleteOne({ _id: id });
        if (deletedUbicacion.deletedCount == 0) return res.status(404).send({ message: 'Ubicación no encontrada y no eliminada' }); // Responde si la ubicación no fue encontrada o eliminada
        return res.send({ message: 'Ubicación eliminada exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al eliminar ubicación' }); // Responde en caso de error
    }
};

//BUSCAR UBICACIONES. 
export const search = async (req, res) => {
    try {
        let { search } = req.body; // Captura el término de búsqueda del cuerpo de la solicitud

        // Busca ubicaciones que coincidan con el término de búsqueda (no sensible a mayúsculas/minúsculas)
        let ubicaciones = await Ubicacion.find({
            ubicacion: { $regex: search, $options: 'i' }
        });

        if (ubicaciones.length == 0) return res.status(404).send({ message: 'No hay ubicaciones que mostrar' }); // Responde si no se encuentran coincidencias
        return res.send({ message: 'Ubicaciones encontradas', ubicaciones }); // Responde con las ubicaciones encontradas
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al buscar ubicación' }); // Responde en caso de error
    }
};
