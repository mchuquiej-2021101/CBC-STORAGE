'use strict'

import mongoose from "mongoose"; // Importa el módulo de Mongoose para interactuar con MongoDB

// Define un esquema para la colección 'ubicacion'
const ubicacionSchema = mongoose.Schema({
    ubicacion: {
        type: String, // El campo 'ubicacion' es una cadena de texto
        required: true
    },
    capacidad: {
        type: Number, // El campo 'capacidad' es un número
        required: true
    }
});

// Exporta el modelo basado en el esquema definido
export default mongoose.model('ubicacion', ubicacionSchema);
