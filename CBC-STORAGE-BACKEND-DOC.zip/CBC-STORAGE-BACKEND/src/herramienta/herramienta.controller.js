'use strict'

import Herramienta from '../herramienta/herramienta.model.js'; // Importa el modelo de Herramienta
import Categoria from '../categoria/categoria.model.js'; // Importa el modelo de Categoría
import Ubicacion from '../ubicacion/ubicacion.model.js'; // Importa el modelo de Ubicación
import Prestamo from '../prestamo/prestamo.model.js'; // Importa el modelo de Prestamo para manejar los préstamos asociados

//CREAR Y GUARDAR HERRAMIENTAS. 
export const save = async (req, res) => {
    try {
        let data = req.body; // Captura los datos del cuerpo de la solicitud
        
        const requiredFields = ['SKU', 'nombre', 'stock', 'marca', 'modelo', 'categoria', 'ubicacion']; // Define los campos requeridos
        
        // Verifica que todos los campos requeridos estén presentes en los datos
        for (let field of requiredFields) {
            if (!data[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` }); // Responde si falta algún campo requerido
            }
        }
        
        // Verifica que el SKU no esté ya en uso
        let existingHerramienta = await Herramienta.findOne({ SKU: data.SKU });
        if (existingHerramienta) {
            return res.status(400).send({ message: 'El SKU ya está en uso, por favor elija otro' }); // Responde si el SKU ya existe
        }

        // Verifica que la categoría especificada exista
        let categoria = await Categoria.findOne({ _id: data.categoria });
        if (!categoria) return res.status(404).send({ message: 'Categoría no encontrada' }); // Responde si la categoría no existe

        // Verifica que la ubicación especificada exista
        let ubicacion = await Ubicacion.findOne({ _id: data.ubicacion });
        if (!ubicacion) return res.status(404).send({ message: 'Ubicación no encontrada' }); // Responde si la ubicación no existe

        console.log(`Capacidad actual: ${ubicacion.capacidad}`); // Imprime la capacidad actual de la ubicación
        console.log(`Stock a agregar: ${data.stock}`); // Imprime el stock a agregar
        
        // Verifica si hay suficiente capacidad en la ubicación para el nuevo stock
        if (data.stock > ubicacion.capacidad) {
            return res.status(400).send({ message: `La ubicación solo tiene espacio para almacenar ${ubicacion.capacidad} herramientas` }); // Responde si no hay suficiente espacio
        }
        
        let nuevaCapacidad = ubicacion.capacidad - data.stock; // Calcula la nueva capacidad de la ubicación
        
        // Actualiza la capacidad de la ubicación después de agregar la herramienta
        let updatedUbicacion = await Ubicacion.findOneAndUpdate(
            { _id: data.ubicacion },
            { capacidad: nuevaCapacidad },
            { new: true } // Retorna la ubicación actualizada
        );
        
        console.log(`Capacidad actualizada: ${updatedUbicacion.capacidad}`); // Imprime la nueva capacidad de la ubicación

        if (!updatedUbicacion) return res.status(500).send({ message: 'Error al actualizar la capacidad de la ubicación' }); // Responde si hubo un error al actualizar la capacidad
             
        let herramienta = new Herramienta(data); // Crea una nueva instancia de Herramienta con los datos proporcionados
        await herramienta.save(); // Guarda la nueva herramienta en la base de datos

        return res.send({ message: 'Herramienta agregada exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al agregar herramienta' }); // Responde en caso de error
    }
}

//OBTENER HERRAMIENTAS. 
export const get = async (req, res) => {
    try {
        let herramientas = await Herramienta.find()
            .populate('ubicacion', ['ubicacion']) // Popula el campo de ubicación con solo la propiedad 'ubicacion'
            .populate('categoria', ['categoria']); // Popula el campo de categoría con solo la propiedad 'categoria'
        if (herramientas.length == 0) return res.status(404).send({ message: 'No hay herramientas que mostrar' }); // Responde si no hay herramientas
        return res.send({ herramientas }); // Responde con la lista de herramientas
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al mostrar las herramientas' }); // Responde en caso de error
    }
}

//ACTUALIZAR HERRAMIENTAS. 
export const update = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID de la herramienta desde los parámetros de la URL
        let data = req.body; // Captura los datos del cuerpo de la solicitud
        
        // Actualiza la herramienta en la base de datos con los nuevos datos
        let updatedHerramienta = await Herramienta.findOneAndUpdate(
            { _id: id },
            data,
            { new: true } // Retorna la herramienta actualizada
        )
        .populate('ubicacion', ['ubicacion']) // Popula el campo de ubicación con solo la propiedad 'ubicacion'
        .populate('categoria', ['categoria']); // Popula el campo de categoría con solo la propiedad 'categoria'
        if (!updatedHerramienta) return res.status(404).send({ message: 'Herramienta no encontrada y/o no actualizada' }); // Responde si la herramienta no fue encontrada o actualizada
        return res.send({ message: 'Herramienta actualizada exitosamente', updatedHerramienta }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al actualizar herramienta' }); // Responde en caso de error
    }
}

//ELIMINAR HERRAMIENTAS.
export const deleteHerramienta = async (req, res) => {
    try {
        const { id } = req.params; // Captura el ID de la herramienta desde los parámetros de la URL

        // Busca o crea una categoría por defecto para reasignar la herramienta
        let defaultCategory = await Categoria.findOne({ categoria: 'Default Category' });
        if (!defaultCategory) {
            defaultCategory = await Categoria.create({ categoria: 'Default Category' });
        }

        // Busca o crea una ubicación por defecto para reasignar la herramienta
        let defaultLocation = await Ubicacion.findOne({ ubicacion: 'Default Location' });
        if (!defaultLocation) {
            defaultLocation = await Ubicacion.create({ ubicacion: 'Default Location', capacidad: 0 });
        }

        // Busca o crea una herramienta por defecto para reasignar los préstamos
        let defaultTool = await Herramienta.findOne({ nombre: 'Default Tool' });
        if (!defaultTool) {
            defaultTool = await Herramienta.create({ nombre: 'Default Tool', SKU: "Default", stock: 0, marca: "Default", modelo: "Default", categoria: defaultCategory._id, ubicacion: defaultLocation._id });
        }

        // Reasigna todos los préstamos asociados a la herramienta eliminada a la herramienta por defecto
        await Prestamo.updateMany({ herramienta: id }, { $set: { herramienta: defaultTool._id } });
        
        // Busca la herramienta a eliminar y su ubicación asociada
        const herramienta = await Herramienta.findById(id).populate('ubicacion');
        if (!herramienta) {
            return res.status(404).send({ message: 'Herramienta no encontrada' }); // Responde si la herramienta no fue encontrada
        }

        const stock = herramienta.stock; // Obtiene el stock actual de la herramienta
        const ubicacionId = herramienta.ubicacion._id; // Obtiene el ID de la ubicación asociada

        // Actualiza la capacidad de la ubicación al eliminar la herramienta
        await Ubicacion.findByIdAndUpdate(
            ubicacionId,
            { $inc: { capacidad: stock } }, // Incrementa la capacidad de la ubicación en la cantidad de stock eliminada
            { new: true }
        );
        
        await Herramienta.deleteOne({ _id: id }); // Elimina la herramienta de la base de datos

        return res.send({ message: 'Herramienta eliminada exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al eliminar la herramienta' }); // Responde en caso de error
    }
}

//BUSCAR HERRAMIENTAS. 
export const search = async (req, res) => {
    try {
        let { search } = req.body; // Captura el término de búsqueda desde el cuerpo de la solicitud
        let herramientas = await Herramienta.find({
            nombre: { $regex: search, $options: 'i' } // Busca herramientas cuyo nombre coincida parcialmente con el término de búsqueda
        })
        .populate('ubicacion', ['ubicacion']) // Popula el campo de ubicación con solo la propiedad 'ubicacion'
        .populate('categoria', ['categoria']); // Popula el campo de categoría con solo la propiedad 'categoria'

        if (herramientas.length == 0) return res.status(404).send({ message: 'No hay herramientas que mostrar' }); // Responde si no se encontraron herramientas
        return res.send({ message: 'Herramientas encontradas', herramientas }); // Responde con las herramientas encontradas
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al buscar herramienta' }); // Responde en caso de error
    }
}
