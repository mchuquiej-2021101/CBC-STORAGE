'use strict'

import mongoose from "mongoose"; // Importa el módulo de Mongoose para interactuar con MongoDB

// Define un esquema para la colección 'herramienta'
const herramientaSchema = mongoose.Schema({
    SKU: {
        type: String, // Define que este campo es una cadena de texto
        required: true, 
        unique: true // Este campo debe ser único en la colección, no se permiten duplicados
    },
    nombre: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    },
    marca: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    },
    modelo: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    },
    stock: {
        type: Number, // Define que este campo es un número
        required: true
    },
    categoria: {
        type: mongoose.Schema.Types.ObjectId, // Define que este campo es un ObjectId que referencia a otro documento
        ref: 'categoria', // Hace referencia a la colección 'categoria'
        required: true, // Este campo es obligatorio
        default: 'Default' // Valor por defecto si no se especifica otro
    },
    ubicacion: {
        type: mongoose.Schema.Types.ObjectId, // Define que este campo es un ObjectId que referencia a otro documento
        ref: 'ubicacion', // Hace referencia a la colección 'ubicacion'
        required: true, // Este campo es obligatorio
        default: 'Default' // Valor por defecto si no se especifica otro
    }
});

// Exporta el modelo basado en el esquema definido
export default mongoose.model('herramienta', herramientaSchema);
