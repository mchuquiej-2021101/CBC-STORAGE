'use strict'

import mongoose from "mongoose"; // Importa el módulo de Mongoose para interactuar con MongoDB

// Define un esquema para la colección 'categoria'
const categoriaSchema = mongoose.Schema({
    categoria: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    }
});

// Exporta el modelo basado en el esquema definido
export default mongoose.model('categoria', categoriaSchema);
