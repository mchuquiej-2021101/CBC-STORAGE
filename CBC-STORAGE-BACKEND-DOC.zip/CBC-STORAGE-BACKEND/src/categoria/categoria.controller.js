'use strict'
import Categoria from './categoria.model.js' // Importa el modelo de Categoría desde la carpeta correspondiente
import Herramienta from '../herramienta/herramienta.model.js' // Importa el modelo de Herramienta para manejar herramientas asociadas a categorías

//CREAR CATEGORÍA.
export const save = async (req, res) => {
    try {
        let data = req.body; // Captura los datos del cuerpo de la solicitud

        // Busca si ya existe una categoría con el mismo nombre
        let categoriaEncontrada = await Categoria.find({ categoria: data.categoria });
        if (categoriaEncontrada.length > 0) {
            return res.status(400).send({ message: 'La categoría ya existe' }); // Responde si la categoría ya existe
        }

        const requiredFields = ['categoria']; // Define los campos requeridos

        // Verifica que los campos requeridos estén presentes en los datos
        for (let field of requiredFields) {
            if (!data[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` });
            }
        }

        let categoria = new Categoria(data); // Crea una nueva instancia de la categoría con los datos
        await categoria.save(); // Guarda la nueva categoría en la base de datos
        return res.send({ message: 'Categoría guardada exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al guardar categoría' }); // Responde en caso de error
    }
}

//OBTENER CATEGORÍA.
export const get = async (req, res) => {
    try {
        let categorias = await Categoria.find(); // Busca todas las categorías en la base de datos
        if (categorias.length === 0) return res.status(404).send({ message: 'No hay categorías que mostrar' }); // Responde si no hay categorías
        return res.send({ categorias }); // Responde con las categorías encontradas
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al mostrar categorías' }); // Responde en caso de error
    }
}

//ACTUALIZAR CATEGORÍA.
export const update = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID de la categoría desde los parámetros de la URL
        let data = req.body; // Captura los datos del cuerpo de la solicitud

        // Verifica si ya existe una categoría con el nuevo nombre
        let categoriaEncontrada = await Categoria.find({ categoria: data.categoria });
        if (categoriaEncontrada.length > 0) {
            return res.status(400).send({ message: 'La categoría ya existe' }); // Responde si la nueva categoría ya existe
        }

        // Actualiza la categoría en la base de datos con los nuevos datos
        let updatedCategoria = await Categoria.findOneAndUpdate(
            { _id: id },
            data,
            { new: true } // Retorna la categoría actualizada
        );

        if (!updatedCategoria) res.status(404).send({ message: 'Categoría no encontrada y no actualizada' }); // Responde si la categoría no fue encontrada o actualizada

        return res.send({ message: 'Categoría actualizada correctamente', updatedCategoria }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al actualizar la categoría' }); // Responde en caso de error
    }
}

//ELIMINAR CATEGORÍA. 
export const deleteCategoria = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID de la categoría desde los parámetros de la URL
         
         // Busca o crea una categoría por defecto para reasignar las herramientas
         let defaultCategory = await Categoria.findOne({ categoria: 'Default Category' });
         if (!defaultCategory) {
             defaultCategory = await Categoria.create({ categoria: 'Default Category' });
         }

         // Reasigna todas las herramientas asociadas a la categoría eliminada a la categoría por defecto
         await Herramienta.updateMany({ categoria: id }, { $set: { categoria: defaultCategory._id } });

        // Elimina la categoría de la base de datos
        let deletedCategoria = await Categoria.deleteOne({ _id: id });

        if (deletedCategoria.deletedCount === 0) return res.status(404).send({ message: 'Categoría no encontrada y no eliminada' }); // Responde si la categoría no fue encontrada o eliminada

        return res.send({ message: 'Categoría eliminada exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al eliminar la categoría' }); // Responde en caso de error
    }
}

//BUSCAR CATEGORÍA. 
export const search = async (req, res) => {
    try {
        let { search } = req.body; // Captura el término de búsqueda desde el cuerpo de la solicitud

        // Busca categorías cuyo nombre coincida parcialmente con el término de búsqueda
        let categorias = await Categoria.find({
            categoria: { $regex: search, $options: 'i' }
        });

        if (categorias.length == 0) return res.status(404).send({ message: 'Categoría no encontrada' }); // Responde si no se encontraron coincidencias
        return res.send({ message: 'Categoría encontrada', categorias }); // Responde con los resultados de la búsqueda
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al buscar categoría' }); // Responde en caso de error
    }
}
