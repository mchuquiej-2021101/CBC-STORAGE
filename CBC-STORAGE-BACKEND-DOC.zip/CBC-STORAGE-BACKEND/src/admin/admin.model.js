import mongoose from "mongoose"; // Importa el módulo de Mongoose para trabajar con MongoDB

// Define un esquema para la colección 'admin'
const adminSchema = mongoose.Schema({
    nombres: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    },
    apellidos: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    },
    usuario: {
        type: String, // Define que este campo es una cadena de texto
        required: true, 
        unique: true // El valor de este campo debe ser único en la base de datos
    },
    email: {
        type: String, // Define que este campo es una cadena de texto
        required: true,
        unique: true // El valor de este campo debe ser único en la base de datos
    },
    contrasena: {
        type: String, // Define que este campo es una cadena de texto
        required: true, 
        minLength: [8, 'Password must be 8 characters'] // La contraseña debe tener al menos 8 caracteres
    },
    telefono: {
        type: String, // Define que este campo es una cadena de texto
        required: true, 
        minLength: 8, // El número de teléfono debe tener al menos 8 caracteres
        maxLength: 8 // El número de teléfono debe tener como máximo 8 caracteres
    }
});

// Exporta el modelo basado en el esquema definido
export default mongoose.model('admin', adminSchema);
