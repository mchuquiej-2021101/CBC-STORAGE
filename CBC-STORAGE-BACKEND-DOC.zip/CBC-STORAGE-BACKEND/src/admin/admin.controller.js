'use strict'
import Admin from '../admin/admin.model.js' // Importa el modelo Admin de la carpeta admin
import { genereteJwt } from '../utils/jwt.js' // Importa la función genereteJwt desde utilidades de JWT
import { encrypt, checkPassword } from '../utils/validator.js' // Importa funciones para encriptar y validar contraseñas
import { authenticateToken } from '../middlewares/authMiddleware.js' // Importa el middleware para autenticar tokens

//REGISTRAR ADMIN.
export const register = async (req, res) => {
    try {
        let data = req.body; // Captura los datos del cuerpo de la solicitud
        
        const requiredFields = ['nombres', 'apellidos', 'usuario', 'email', 'contrasena', 'telefono']; // Campos requeridos

        // Verifica que todos los campos requeridos estén presentes en los datos
        for (let field of requiredFields) {
            if (!data[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` });
            }
        }

        // Verifica que la contraseña cumpla con ciertos requisitos de seguridad
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
        if (!data.contrasena || typeof data.contrasena !== 'string' || !passwordRegex.test(data.contrasena)) {
            return res.status(400).send({ 
                message: 'La contraseña debe tener mínimo 8 caracteres, incluyendo al menos una letra mayúscula, una letra minúscula, un número y un carácter especial.' 
            });
        }

        data.contrasena = await encrypt(data.contrasena); // Encripta la contraseña antes de guardarla

        // Verifica si el usuario ya existe en la base de datos
        let usuarioEncontrado = await Admin.findOne({ usuario: data.usuario })
        if(usuarioEncontrado) return res.status(500).send({ message: 'El usuario ya existe' })
        
        // Verifica si el email ya está registrado con otro usuario
        let emailEncontrado = await Admin.findOne({ email: data.email })
        if(emailEncontrado) return res.status(500).send({ message: 'El email ya está vinculado a otro usuario' })

        let admin = new Admin(data); // Crea una nueva instancia del modelo Admin con los datos
        await admin.save(); // Guarda el nuevo administrador en la base de datos

        return res.status(200).send({ message: 'Registrado exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al registrar usuario' }); // Responde en caso de error
    }
};

//INICIAR SESIÓN.
export const login = async (req, res) => {
    try {
        const { usuario, contrasena } = req.body; // Captura usuario y contraseña del cuerpo de la solicitud
        
        const requiredFields = ['usuario', 'contrasena']; // Campos requeridos para iniciar sesión
        for (let field of requiredFields) {
            if (!req.body[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` });
            }
        }
        
        let admin = await Admin.findOne({ usuario }); // Busca el administrador por su usuario
        if (!admin) {
            console.log('Administrador no encontrado');
            return res.status(404).send({ message: 'Credenciales inválidas' });
        }
        
        const isPasswordValid = await checkPassword(contrasena, admin.contrasena); // Verifica que la contraseña sea correcta        

        if (isPasswordValid) {
            // Si la contraseña es válida, se crea un objeto de usuario y se genera un token JWT
            const loggedUser = {
                uid: admin._id,
                usuario: admin.usuario,
                nombres: admin.nombres,
                apellidos: admin.apellidos
            };
            const token = await genereteJwt(loggedUser); // Genera un token JWT

            return res.send({
                message: `Welcome ${admin.nombres}`, // Responde con un mensaje de bienvenida
                loggedUser,
                token
            });
        }

        return res.status(404).send({ message: 'Credenciales inválidas' }); // Responde con error si las credenciales no son válidas
    } catch (error) {
        console.error('Error al iniciar sesión:', error);
        return res.status(500).send({ message: 'Error al iniciar sesión' }); // Responde en caso de error
    }
};

//ACTUALIZAR ADMIN.
export const update = async (req, res) => {
    try {
        const { id } = req.params; // Captura el ID del usuario desde los parámetros de la URL
        const data = req.body; // Captura los datos del cuerpo de la solicitud
        
        // Verifica que el usuario autenticado sea el mismo que se intenta actualizar
        if (req.user.uid !== id) {
            return res.status(403).send({ message: 'No autorizado para actualizar este usuario' });
        }

        // Verifica que la nueva contraseña cumpla con ciertos requisitos de seguridad
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
        if (!data.contrasena || typeof data.contrasena !== 'string' || !passwordRegex.test(data.contrasena)) {
            return res.status(400).send({ 
                message: 'La contraseña debe tener mínimo 8 caracteres, incluyendo al menos una letra mayúscula, una letra minúscula, un número y un carácter especial.' 
            });
        }

        data.contrasena = await encrypt(data.contrasena); // Encripta la nueva contraseña

        // Actualiza el administrador en la base de datos con los nuevos datos
        const updatedAdmin = await Admin.findOneAndUpdate(
            { _id: id },
            data,
            { new: true }
        );

        if (!updatedAdmin) {
            return res.status(404).send({ message: 'Usuario no encontrado y/o no actualizado' }); // Responde si el usuario no fue encontrado o actualizado
        }

        return res.send({ message: 'Usuario actualizado exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error('Error al actualizar usuario:', error);
        return res.status(500).send({ message: 'Error al actualizar usuario' }); // Responde en caso de error
    }
};

//ELIMINAR ADMIN.
export const deleteAdmin = async (req, res) => {
    try {
        const { id } = req.params; // Captura el ID del usuario desde los parámetros de la URL
        
        // Verifica que el usuario autenticado sea el mismo que se intenta eliminar
        if (req.user.uid !== id) {
            return res.status(403).send({ message: 'No autorizado para eliminar este usuario' });
        }

        const deletedAdmin = await Admin.findOneAndDelete({ _id: id }); // Elimina el administrador de la base de datos
        if (!deletedAdmin) {
            return res.status(404).send({ message: 'Usuario no encontrado y/o no eliminado' }); // Responde si el usuario no fue encontrado o eliminado
        }

        return res.send({ message: 'Usuario eliminado exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error('Error al eliminar usuario:', error);
        return res.status(500).send({ message: 'Error al eliminar Usuario' }); // Responde en caso de error
    }
};

//BUSCAR ADMIN.
export const search = async (req, res) => {
    try {
        let { search } = req.body; // Captura el término de búsqueda desde el cuerpo de la solicitud
        
        // Busca administradores cuyo nombre coincida parcialmente con el término de búsqueda
        let admins = await Admin.find({
            nombres: { $regex: search, $options: 'i' }
        });

        if (admins.length == 0) {
            return res.status(404).send({ message: 'Usuario no encontrado' }); // Responde si no se encontraron coincidencias
        }

        return res.send({ message: 'Usuario encontrado', admins }); // Responde con los resultados de la búsqueda
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al buscar usuario' }); // Responde en caso de error
    }
}
