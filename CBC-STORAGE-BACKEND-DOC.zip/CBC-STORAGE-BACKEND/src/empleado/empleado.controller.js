'use strict'

import Empleado from './empleado.model.js'; // Importa el modelo de Empleado desde el archivo correspondiente
import Prestamo from '../prestamo/prestamo.model.js'; // Importa el modelo de Prestamo para manejar préstamos asociados a empleados

//CREAR Y GUARDAR EMPLEADO. 
export const save = async (req, res) => {
    try {
        let data = req.body; // Captura los datos del cuerpo de la solicitud
        
        const requiredFields = ['nombres', 'apellidos', 'email', 'telefono']; // Define los campos requeridos
        
        // Verifica que los campos requeridos estén presentes en los datos
        for (let field of requiredFields) {
            if (!data[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` }); // Responde si falta algún campo requerido
            }
        }
        
        // Validación para asegurar que el teléfono no esté ya asignado a otro empleado
        let telefonoEncontrado = await Empleado.find({ telefono: data.telefono });
        if (telefonoEncontrado.length > 0) {
            return res.status(400).send({ message: 'El número de teléfono ya está asignado a otra persona' }); // Responde si el teléfono ya está en uso
        }

        // Validación para asegurar que el email no esté ya asignado a otro empleado
        let emailEncontrado = await Empleado.find({ email: data.email });
        if (emailEncontrado.length > 0) {
            return res.status(400).send({ message: 'El email ya está asignado a otra persona' }); // Responde si el email ya está en uso
        }
                
        let empleado = new Empleado(data); // Crea una nueva instancia de Empleado con los datos proporcionados
        await empleado.save(); // Guarda el nuevo empleado en la base de datos
        return res.send({ message: 'Empleado guardado exitosamente' }); // Responde con éxito
    } catch (error) {
        console.log(error);
        return res.status(500).send({ message: 'Error guardando empleado' }); // Responde en caso de error
    }
}

//OBTENER LOS EMPLEADOS. 
export const get = async (req, res) => {
    try {
        let empleados = await Empleado.find(); // Busca todos los empleados en la base de datos
        if (empleados.length == 0) return res.status(500).send({ message: 'No hay empleados que mostrar' }); // Responde si no hay empleados
        return res.send({ empleados }); // Responde con la lista de empleados
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al obtener empleados' }); // Responde en caso de error
    }
}

//ACTUALIZAR EMPLEADOS. 
export const update = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID del empleado desde los parámetros de la URL
        let data = req.body; // Captura los datos del cuerpo de la solicitud

        // Validación para asegurar que el teléfono no esté ya asignado a otro empleado
        let telefonoEncontrado = await Empleado.find({ telefono: data.telefono });
        if (telefonoEncontrado.length > 0) {
            return res.status(400).send({ message: 'El número de teléfono ya está asignado a otra persona' }); // Responde si el teléfono ya está en uso
        }

        // Validación para asegurar que el email no esté ya asignado a otro empleado
        let emailEncontrado = await Empleado.find({ email: data.email });
        if (emailEncontrado.length > 0) {
            return res.status(400).send({ message: 'El email ya está asignado a otra persona' }); // Responde si el email ya está en uso
        }

        // Actualiza el empleado en la base de datos con los nuevos datos
        let updatedEmpleado = await Empleado.findOneAndUpdate(
            { _id: id },
            data,
            { new: true } // Retorna el empleado actualizado
        );

        if (!updatedEmpleado) return res.status(404).send({ message: 'Empleado no encontrado y no actualizado' }); // Responde si el empleado no fue encontrado o actualizado

        return res.send({ message: 'Empleado actualizado exitosamente', updatedEmpleado }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al actualizar empleado' }); // Responde en caso de error
    }
}

//ELIMINAR EMPLEADOS. 
export const deleteEmpleado = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID del empleado desde los parámetros de la URL

        // Busca o crea un empleado por defecto para reasignar los préstamos
        let defaultEmployee = await Empleado.findOne({ nombres: 'Default Employee' });
        if (!defaultEmployee) {
            defaultEmployee = await Empleado.create({ nombres: 'Default Employee', apellidos: "Default", email: "Default", telefono: "Default " });
        }

        // Reasigna todos los préstamos asociados al empleado eliminado al empleado por defecto
        await Prestamo.updateMany({ empleado: id }, { $set: { empleado: defaultEmployee._id } });
                
        // Elimina el empleado de la base de datos
        let deletedEmpleado = await Empleado.deleteOne({ _id: id });
                
        if (deletedEmpleado.deletedCount === 0) {
            return res.status(404).send({ message: 'Empleado no encontrado y no eliminado' }); // Responde si el empleado no fue encontrado o eliminado
        }
        
        return res.send({ message: 'Empleado eliminado exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al eliminar empleado' }); // Responde en caso de error
    }
}

//BUSCAR EMPLEADOS. 
export const search = async (req, res) => {
    try {
        let { search } = req.body; // Captura el término de búsqueda desde el cuerpo de la solicitud
        
        // Busca empleados cuyo nombre coincida parcialmente con el término de búsqueda
        let empleados = await Empleado.find({
            nombres: { $regex: search, $options: 'i' }
        });

        if (empleados.length == 0) {
            return res.status(404).send({ message: 'Empleado no encontrado' }); // Responde si no se encontraron coincidencias
        }

        return res.send({ message: 'Empleado encontrado', empleados }); // Responde con los resultados de la búsqueda
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al buscar empleado' }); // Responde en caso de error
    }
}