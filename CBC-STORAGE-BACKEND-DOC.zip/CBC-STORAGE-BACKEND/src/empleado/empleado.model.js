import mongoose from 'mongoose'; // Importa el módulo de Mongoose para interactuar con MongoDB

// Define un esquema para la colección 'empleado'
const empleadoSchema = mongoose.Schema({
    nombres: {
        type: String, // Define que este campo es una cadena de texto
        required: true 
    },
    apellidos: {
        type: String, // Define que este campo es una cadena de texto
        required: true
    },
    email: {
        type: String, // Define que este campo es una cadena de texto
        required: true
    },
    telefono: {
        type: String, // Define que este campo es una cadena de texto
        minLength: 8, // Define la longitud mínima del teléfono como 8 caracteres
        maxLength: 8, // Define la longitud máxima del teléfono como 8 caracteres
        required: true
    }
});

// Exporta el modelo basado en el esquema definido
export default mongoose.model('empleado', empleadoSchema);
