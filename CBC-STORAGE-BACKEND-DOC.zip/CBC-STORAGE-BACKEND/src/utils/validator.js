import { compare, hash } from "bcrypt"; 

//FUNCIÓN PARA ENCRIPTAR UNA CONTRASEÑA.
export const encrypt = async (password) => {
    try {
        return await hash(password, 10); //GENERA UN HASH SEGURO.
    } catch (error) {
        console.error(error); //IMPRIME CUALQUIER ERROR.
        return error; //RETORNA EL ERROR EN CASO DE EXISTIR UNO. 
    }
};

//FUNCION PARA VERIFICAR SI UNA CONTRASEÑA COINCIDE CON UN HAS ENCRIPTADO.
export const checkPassword = async (password, hash) => {
    try {
        return await compare(password, hash); //COMPARA LA CONTRASEÑA PROPORCIONADA CON EL HAS ALMACENADO.
    } catch (error) {
        console.error(error); //IMPRIME CUALQUIER ERROR.
        return error; //RETORNA EL ERROR EN CASO DE EXISTIR UNO.
    }
    
}; //CERRAMOS LA FUNCIÓN.
