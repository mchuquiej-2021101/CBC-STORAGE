'use strict'
import jwt from 'jsonwebtoken'

const secretKey = '@CBC8d42e9d4f3a29b1e7cbd34f1d937fc8e3f6f86a@' //DEFINE LA CLAVE SECRETA DEFINIDA PARA FIRMAR EL JWT. ESTA CLAVE DEBE MANERNERSE PRIVADA Y SEGURA.

//GENERAR JWT
export const genereteJwt = async (payload) => {
    try {
        //GENERA UN JWT USANDO LA CLAVE SECRETE DEFINIDA. 
        return jwt.sign(payload, secretKey, {
            expiresIn: '3h', //ESTO QUIERE DECIR QUE EL TOKEN EXPIRA EN 3 HORAS.
            algorithm: 'HS256' //UTILIZA EL ALGORITMO HMAC SHA-256 PARA FIRMAR EL TOKEN.
        });
    } catch (error) {
        console.error(error); //IMPRIME EL ERROR EN LA CONSOLA PARA LA DEPURACIÓN.
        return error; //RETORNA EL ERROR EN CASO DE FALLO AL GENERAL EL JWT.
    }
} //CERRAMOS LA FUNCIÓN. 
