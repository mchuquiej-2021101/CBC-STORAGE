'use strict'

import mongoose from "mongoose"; // Importa el módulo de Mongoose para interactuar con MongoDB

// Define un esquema para la colección 'prestamo'
const prestamoSchema = mongoose.Schema({
    herramienta: {
        type: mongoose.Schema.Types.ObjectId, // Define que este campo es un ObjectId que referencia a otro documento
        ref: 'herramienta', // Hace referencia a la colección 'herramienta'
        required: true 
    },
    cantidadHerramientas: {
        type: Number, // Define que este campo es un número
        required: true 
    },
    empleado: {
        type: mongoose.Schema.Types.ObjectId, // Define que este campo es un ObjectId que referencia a otro documento
        ref: 'empleado', // Hace referencia a la colección 'empleado'
        required: true 
    },
    fechaPrestamo: {
        type: Date, // Define que este campo es de tipo fecha
        required: true 
    },
    fechaDevolucion: {
        type: Date // Define que este campo es de tipo fecha
    },
    estado: {
        type: String, // Define que este campo es una cadena de texto
        enum: ['NO DEVUELTO', 'DEVUELTO'], // Define que solo puede tomar uno de estos dos valores
        required: true 
    }
});

// Exporta el modelo basado en el esquema definido
export default mongoose.model('prestamo', prestamoSchema);
