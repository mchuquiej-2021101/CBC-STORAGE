'use strict'
import Prestamo from '../prestamo/prestamo.model.js'; // Importa el modelo de Préstamo
import Herramienta from '../herramienta/herramienta.model.js'; // Importa el modelo de Herramienta
import Empleado from '../empleado/empleado.model.js'; // Importa el modelo de Empleado
import Ubicacion from '../ubicacion/ubicacion.model.js'; // Importa el modelo de Ubicación

//CREAR Y GUARDAR PRESTAMOS. 
export const save = async (req, res) => {
    try {
        let data = req.body; // Captura los datos del cuerpo de la solicitud

        // Campos requeridos para crear un préstamo
        const requiredFields = ['herramienta', 'cantidadHerramientas', 'empleado']; 
                
        // Verifica que todos los campos requeridos estén presentes en los datos
        for (let field of requiredFields) {
            if (!data[field]) {
                return res.status(400).send({ message: `El campo ${field} es obligatorio` }); // Responde si falta algún campo requerido
            }
        }
       
        // Verifica que la herramienta especificada exista
        let herramienta = await Herramienta.findOne({ _id: data.herramienta });
        if (!herramienta) return res.status(404).send({ message: 'Herramienta no existente' });

        // Verifica que el empleado especificado exista
        let empleado = await Empleado.findOne({ _id: data.empleado });
        if (!empleado) return res.status(404).send({ message: 'Empleado no existente' });

        // Verifica que la ubicación asociada a la herramienta exista
        let ubicacion = await Ubicacion.findOne({ _id: herramienta.ubicacion });
        if (!ubicacion) return res.status(400).send({ message: 'Ubicación no existente' });

        console.log(ubicacion); // Imprime la ubicación para verificación
        
        // Asigna la fecha de préstamo actual y el estado por defecto
        data.fechaPrestamo = new Date();
        data.estado = 'NO DEVUELTO';

        // Verifica si hay suficiente stock para el préstamo
        if (data.cantidadHerramientas > herramienta.stock) {
            return res.status(400).send({ message: 'No hay stock suficiente' }); // Responde si no hay suficiente stock
        }

        // Calcula el nuevo stock de la herramienta después del préstamo
        let nuevoStock = herramienta.stock - data.cantidadHerramientas;
        let updatedHerramienta = await Herramienta.findOneAndUpdate(
            { _id: data.herramienta },
            { stock: nuevoStock },
            { new: true } // Retorna la herramienta actualizada
        );

        if (!updatedHerramienta) return res.status(500).send({ message: 'Error al actualizar stock de herramientas' });

        // Calcula la nueva capacidad de la ubicación después del préstamo
        let nuevaCapacidad = Number(ubicacion.capacidad) + Number(data.cantidadHerramientas);

        console.log(nuevaCapacidad); // Imprime la nueva capacidad para verificación
        let updatedUbicacion = await Ubicacion.findOneAndUpdate(
            { _id: herramienta.ubicacion },
            { capacidad: nuevaCapacidad },
            { new: true } // Retorna la ubicación actualizada
        );

        if (!updatedUbicacion) return res.status(500).send({ message: 'Error al actualizar la capacidad de ubicación' });

        // Crea un nuevo préstamo y lo guarda en la base de datos
        let prestamo = new Prestamo(data);
        await prestamo.save();

        return res.send({ message: 'Préstamo guardado exitosamente' });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al agregar préstamo' }); // Responde en caso de error
    }
};

//OBTENER PRESTAMOS. 
export const get = async (req, res) => {
    try {
        let prestamos = await Prestamo.find()
            .populate('herramienta', ['nombre']) // Popula el campo de herramienta con solo la propiedad 'nombre'
            .populate('empleado', ['nombres']); // Popula el campo de empleado con solo la propiedad 'nombres'
        
        if (prestamos.length == 0) return res.status(404).send({ message: 'No hay préstamos que mostrar' }); // Responde si no hay préstamos
        return res.send({ prestamos }); // Responde con la lista de préstamos
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al obtener préstamos' }); // Responde en caso de error
    }
};

//ACTUALIZAR PRESTAMO. 
export const update = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID del préstamo desde los parámetros de la URL
        let data = req.body; // Captura los datos del cuerpo de la solicitud

        // Si el estado del préstamo es 'DEVUELTO', asigna la fecha de devolución actual
        if (data.estado == 'DEVUELTO') {
            data.fechaDevolucion = new Date();
        }

        // Actualiza el préstamo en la base de datos con los nuevos datos
        let updatedPrestamo = await Prestamo.findOneAndUpdate(
            { _id: id },
            data,
            { new: true } // Retorna el préstamo actualizado
        )
        .populate('herramienta', ['nombre']) // Popula el campo de herramienta con solo la propiedad 'nombre'
        .populate('empleado', ['nombres']); // Popula el campo de empleado con solo la propiedad 'nombres'

        if (!updatedPrestamo) return res.status(404).send({ message: 'Préstamo no encontrado y/o no actualizado' }); // Responde si el préstamo no fue encontrado o actualizado
        return res.send({ message: 'Préstamo actualizado exitosamente', updatedPrestamo }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al actualizar préstamo' }); // Responde en caso de error
    }
};

//ELIMINAR PRESTAMO.
export const deletePrestamo = async (req, res) => {
    try {
        let { id } = req.params; // Captura el ID del préstamo desde los parámetros de la URL

        // Busca el préstamo a eliminar
        let prestamo = await Prestamo.findOne({ _id: id });
        if (!prestamo) return res.status(404).send({ message: 'Préstamo no encontrado' });

        // Busca la herramienta asociada al préstamo
        let herramienta = await Herramienta.findOne({ _id: prestamo.herramienta });
        if (!herramienta) return res.status(404).send({ message: 'Herramienta no encontrada' });

        // Busca la ubicación asociada a la herramienta
        let ubicacion = await Ubicacion.findOne({ _id: herramienta.ubicacion });
        if (!ubicacion) return res.status(404).send({ message: 'Ubicación no encontrada' });

        // Calcula el nuevo stock de la herramienta al eliminar el préstamo
        let nuevoStock = Number(herramienta.stock) + Number(prestamo.cantidadHerramientas);
        let updatedHerramienta = await Herramienta.findOneAndUpdate(
            { _id: prestamo.herramienta },
            { stock: nuevoStock },
            { new: true } // Retorna la herramienta actualizada
        );
        if (!updatedHerramienta) return res.status(500).send({ message: 'Error al actualizar stock de herramienta' });

        // Calcula la nueva capacidad de la ubicación al eliminar el préstamo
        let nuevaCapacidad = Number(ubicacion.capacidad) - Number(prestamo.cantidadHerramientas);
        let updatedUbicacion = await Ubicacion.findOneAndUpdate(
            { _id: herramienta.ubicacion },
            { capacidad: nuevaCapacidad },
            { new: true } // Retorna la ubicación actualizada
        );
        if (!updatedUbicacion) return res.status(500).send({ message: 'Error al actualizar capacidad de ubicación' });

        // Elimina el préstamo de la base de datos
        let deletedPrestamo = await Prestamo.deleteOne({ _id: id });
        if (deletedPrestamo.deletedCount == 0) return res.status(404).send({ message: 'Préstamo no encontrado y/o no eliminado' }); // Responde si el préstamo no fue encontrado o eliminado
        return res.send({ message: 'El préstamo se eliminó exitosamente' }); // Responde con éxito
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Error al eliminar préstamo' }); // Responde en caso de error
    }
};